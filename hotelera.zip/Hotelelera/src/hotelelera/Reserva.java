
package hotelelera;

public class Reserva {
    
    private Habitaciones[] coleccionDeReservas;

    public Reserva() {
    }

    public Habitaciones[] getColeccionDeReservas() {
        return coleccionDeReservas;
    }

    public void setColeccionDeReservas(Habitaciones[] coleccionDeReservas) {
        this.coleccionDeReservas = coleccionDeReservas;
    }
    
    public void mostrarInformacionDeReservas() {
        for (Habitaciones habitacion : coleccionDeReservas) {
            System.out.println("Numero de habitacion: " + habitacion.getnDeHabitación());
            System.out.println("Tipo de habitacion: " + habitacion.getTipoDeHabitación());
            System.out.println("Precio: " + habitacion.getPrecio());
            System.out.println("Disponibilidad: " + habitacion.getDisponibilidad());
            System.out.println("Cliente: " + habitacion.getNombre() + " " + habitacion.getApellido());
            System.out.println("Numero de identificacion del cliente: " + habitacion.getnDeIdentificación());
            System.out.println("-------------------------------------");
        }
    }
}