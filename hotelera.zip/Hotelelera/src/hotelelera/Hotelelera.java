package hotelelera;

public class Hotelelera {

    public static void main(String[] args) {

        Habitaciones h1 = new Habitaciones(1,"individual", 100, "Ocupada", "mateo", "Guadalupe", 13);
        Habitaciones h2 = new Habitaciones(2,"doble", 150, "Ocupada", "David", "hernandez", 13);
        Habitaciones h3 = new Habitaciones(3,"individual", 100, "Ocupada", "Elviz", "Claudette", 13);
        Habitaciones h4 = new Habitaciones(14,"suit", 250, "Ocupada", "Emmanuel", "Landero", 13);
        Habitaciones h5 = new Habitaciones(15,"suit", 250, "Ocupada", "Alexander", "Wenceslao", 13);

        Habitaciones [] coleccionDeR={h1, h2,h3,h4, h5};
        
        Reserva r1 = new Reserva();
        r1.setColeccionDeReservas(coleccionDeR);
        System.out.println("Bienvenido");
        System.out.println("Favor de ingresar sus datos:");
        r1.mostrarInformacionDeReservas();
    }
    
}
