
package hotelelera;

public class Clientes {
    private String nombre;
    private String apellido;
    private int nDeIdentificación;

    public Clientes(String Nombre, String Apellido, int nDeIdentificación) {
        this.nombre = Nombre;
        this.apellido = Apellido;
        this.nDeIdentificación = nDeIdentificación;
    }

    public Clientes() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String Apellido) {
        this.apellido = Apellido;
    }

    public int getnDeIdentificación() {
        return nDeIdentificación;
    }

    public void setnDeIdentificación(int nDeIdentificación) {
        this.nDeIdentificación = nDeIdentificación;
    }
    
}
