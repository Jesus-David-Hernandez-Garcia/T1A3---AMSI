
package hotelelera;

public class Clientes {
    private String nombre;
    private String apellido;

    public Clientes(String Nombre, String Apellido) {
        this.nombre = Nombre;
        this.apellido = Apellido;
    }

    public Clientes() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String Apellido) {
        this.apellido = Apellido;
    }
    
}
