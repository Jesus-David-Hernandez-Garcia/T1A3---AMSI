
package hotelelera;

public class Reserva {
    private Habitaciones[] coleccionDeReservas;

    public Reserva() {
    }

    public Habitaciones[] getColeccionDeReservas() {
        return coleccionDeReservas;
    }

    public void setColeccionDeReservas(Habitaciones[] coleccionDeReservas) {
        this.coleccionDeReservas = coleccionDeReservas;
    }

    public void realizarReserva(String nombre, String apellido, String ciudad, String tipoHabitacion, int cantidadAdultos, int cantidadNinos, String diaEntrada, String diaSalida, String metodoPago) {

        System.out.println("-------------------------------------");
        System.out.println("Reserva realizada con exito. Detalles de la reserva:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellido: " + apellido);
        System.out.println("Ciudad de Reserva: " + ciudad);
        System.out.println("Tipo de Habitacion: " + tipoHabitacion);
        System.out.println("Cantidad de Adultos: " + cantidadAdultos);
        System.out.println("Cantidad de Ninos: " + cantidadNinos);
        System.out.println("Dia de Entrada: " + diaEntrada);
        System.out.println("Dia de Salida: " + diaSalida);
        System.out.println("Precio: " + "200 por dia" );
        System.out.println("Metodo de Pago: " + metodoPago);
        System.out.println("-------------------------------------");
    }
}