package hotelelera;

import java.util.Scanner;
public class Hotelelera {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenido");
        System.out.println("Favor de ingresar sus datos:");

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("Ciudad de Reserva: ");
        String ciudad = scanner.nextLine();

        System.out.print("Tipo de Habitacion (individual o doble): ");
        String tipoHabitacion = scanner.nextLine();

        System.out.print("Cantidad de Adultos: ");
        int cantidadAdultos = scanner.nextInt();

        System.out.print("Cantidad de Ninos: ");
        int cantidadNinos = scanner.nextInt();
        scanner.nextLine();  

        System.out.print("Dia de Entrada (14/02/24): ");
        String diaEntrada = scanner.nextLine();

        System.out.print("Dia de Salida (15/02/24): ");
        String diaSalida = scanner.nextLine();

        System.out.print("Metodo de Pago (Tarjeta de Debito o Credito): ");
        String metodoPago = scanner.nextLine();
             
        Reserva r1 = new Reserva();

        r1.realizarReserva(nombre, apellido, ciudad, tipoHabitacion, cantidadAdultos, cantidadNinos, diaEntrada, diaSalida, metodoPago);
        
        scanner.close();
    }
}