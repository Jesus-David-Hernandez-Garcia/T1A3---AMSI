
package hotelelera;

public class Habitaciones extends Clientes{
    private int nDeHabitación;
    private String tipoDeHabitación;
    private int precio;
    private String disponibilidad;

    public Habitaciones(String Nombre, String Apellido) {
        super(Nombre, Apellido);
    }

    public Habitaciones() {
    }

    public Habitaciones(int nDeHabitación, String tipoDeHabitación, int precio, String disponibilidad, String Nombre, String Apellido) {
        super(Nombre, Apellido);
        this.nDeHabitación = nDeHabitación;
        this.tipoDeHabitación = tipoDeHabitación;
        this.precio = precio;
        this.disponibilidad = disponibilidad;
    }

    public int getnDeHabitación() {
        return nDeHabitación;
    }

    public void setnDeHabitación(int nDeHabitación) {
        this.nDeHabitación = nDeHabitación;
    }

    public String getTipoDeHabitación() {
        return tipoDeHabitación;
    }

    public void setTipoDeHabitación(String tipoDeHabitación) {
        this.tipoDeHabitación = tipoDeHabitación;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(String disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

}
